import pandas as pd
#df = pd.read_csv("test.csv")

#print(df.loc[df['Name'], '.* an .*', ['Name', 'Age']])
message5 = "bonjour le monde"
message5a = message5.find("mond")
print(message5a)
