#Excel to DF
import pandas as pd
df=pd.read_excel('rattra.xls',sheet_name='essai')
print (df)
df.to_csv('xls_to_csv.csv', index=False)
