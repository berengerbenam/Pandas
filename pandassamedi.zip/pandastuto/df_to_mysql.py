import pymysql
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
def database():
    global conn,cursor
    conn = pymysql.connect(host='localhost',user='bessan',password='passer',db='animal')
    cursor = conn.cursor()

#cnx = create_engine('mysql+pymysql://bessan:passer@localhost:3306/animal').connect()
df=pd.read_excel('rattra.xls',sheet_name='essai',header=1)

my_dict={
	'class':['Five','Six','Three'],
	'No':[5,2,3]
	}
print ((df.to_string(index=False)))
