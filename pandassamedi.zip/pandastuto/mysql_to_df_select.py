#MYSQL to DF + DF to CSV : Cas de select
import pandas as pd
import numpy as np
from sqlalchemy import create_engine
cnx = create_engine('mysql+pymysql://bessan:passer@localhost:3306/animal').connect()
sql = 'select * from Animal'
df = pd.read_sql(sql, cnx)
print(df)
df.to_csv('sqltocsv.csv', index=False)
