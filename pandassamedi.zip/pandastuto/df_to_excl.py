#DF to Excel et Classeur avec plusieurs feuilles
import pandas as pd
df = pd.DataFrame([['SALL', 'Macky'], ['SENGHOR', 'Leopold'],['TALON', 'Patrice'],['WADE', 'Abdoulaye']],columns=['NOM', 'PRENOM'])
df3=pd.DataFrame([['BONNO', 'Mar'], ['TOG', 'OLE'],['INO', 'TAT'],['DIOP', 'Kerekou']],columns=['NOM', 'PRENOM'])
df2 =  pd.DataFrame([['BONGO', 'Omar'], ['SEN', 'Leo'],['ONI', 'Pat'],['DIOUF', 'Abdou']],columns=['NOM', 'PRENOM'])
with pd.ExcelWriter('base.xlsx') as writer:
    df.to_excel(writer, sheet_name='feuille1')
    df2.to_excel(writer, sheet_name='feuille2')
    df3.to_excel(writer, sheet_name='presidents')
